
import time

def main():
    print("Бот запущен и работает...")
    while True:
        time.sleep(10)
        print("Анализ данных...")

if __name__ == "__main__":
    main()
